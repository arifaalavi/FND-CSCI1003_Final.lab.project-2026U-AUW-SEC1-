// ===============================
// PROJECT ELYSIUM
// Part 1 - Opening & Identity

// 

const startBtn = document.getElementById("startBtn");
const introMessage = document.getElementById("introMessage");
const hero = document.getElementById("hero");

// ---------- Screens ----------
const identityScreen = document.getElementById("identityScreen");
const gameScreen = document.getElementById("gameScreen");

// ---------- Identity ----------
const cards = document.querySelectorAll(".card");
const identityMessage = document.getElementById("identityMessage");
const continueBtn = document.getElementById("continueBtn");

let chosenIdentity = "";
let playerHistory = [];
let clueFound = false;
// ===============================
// Begin Your Story
// ===============================

startBtn.addEventListener("click", function () {

    introMessage.style.opacity = "1";

    setTimeout(function () {

        hero.style.display = "none";
        identityScreen.style.display = "flex";

    }, 2000);

});

// ===============================
// Identity Selection
// ===============================

cards.forEach(function (card) {

    card.addEventListener("click", function () {

        cards.forEach(function (c) {

            c.classList.remove("selected");
            c.classList.add("faded");

        });

        card.classList.remove("faded");
        card.classList.add("selected");

        chosenIdentity = card.id;

        identityMessage.style.opacity = "1";
        continueBtn.style.display = "inline-block";

    });

});

// ===============================
// Continue Button
// ===============================

continueBtn.addEventListener("click", function () {

    identityScreen.style.display = "none";
    gameScreen.style.display = "flex";
    updateProgress(25);

    document.getElementById("welcomeTitle").textContent =
        "Welcome " +
        chosenIdentity.charAt(0).toUpperCase() +
        chosenIdentity.slice(1);

});
// ===============================
// Part 2 - Choices & Story
// ===============================

// ---------- Story Elements ----------

const result = document.getElementById("resultText");

const choice1 = document.getElementById("choice1");
const choice2 = document.getElementById("choice2");
const choice3 = document.getElementById("choice3");


// ===============================
// Story Animation
// ===============================

function showStory(lines){

    result.innerHTML = "";
    result.style.opacity = "1";

    let index = 0;

    function nextLine(){

        if(index < lines.length){

            result.innerHTML += lines[index] + "<br>";

            index++;

            setTimeout(nextLine,1200);

        }

    }

    nextLine();

}


// ===============================
// Choice 1
// ===============================

   

    
// ===============================
// Choice 1
// ===============================

choice1.addEventListener("click", function(){

    if(chosenIdentity === "guardian"){

        showStory([
            "Your protective instinct guides you...",
            "You search the hall carefully...",
            "You discover a hidden clue."
        ]);
        setTimeout(function(){

    updateProgress(100);

    showEnding("The Silent Protector");

},2000);

        playerHistory.push("searched");

        if(!clueFound){
            addItem("Hidden Clue");
            updateProgress(50);
            setTimeout(function(){

    updateProgress(100);

    showEnding("The Silent Protector");

},4000);
            clueFound = true;
        }

        console.log(playerHistory);

    }
    

    else if(chosenIdentity === "architect"){

        showStory([
            "Your planning skills reveal a pattern...",
            "You inspect every corner...",
            "You find the missing ring."
        ]);

    }

    else if(chosenIdentity === "heart"){

        showStory([
            "You notice everyone's emotions...",
            "Someone quietly trusts you...",
            "A new path appears."
        ]);

    }

});

// ===============================
// Choice 2
// ===============================

choice2.addEventListener("click", function(){

    showStory([
        "You decide to buy another ring...",
        "Time is running out...",
        "A mysterious stranger smiles."
    ]);
    playerHistory.push("newRing");
    
    console.log(playerHistory);

});


// ===============================
// Choice 3
// ===============================

choice3.addEventListener("click", function(){

    showStory([
        "You tell everyone immediately...",
        "The guests become silent...",
        "The story takes an unexpected turn."
    ]);
    playerHistory.push("toldEveryone");
    
    console.log(playerHistory);

});
function updateProgress(percent){

    document.getElementById("progressFill").style.width = percent + "%";

}
function showAchievement(title){

    const popup = document.getElementById("achievementPopup");

    popup.innerHTML = `
        🏆 Achievement Unlocked!<br>
        <span>${title}</span>
    `;

    popup.style.opacity = "1";
    popup.style.transform = "translateX(0)";

    setTimeout(function(){

        popup.style.opacity = "0";
        popup.style.transform = "translateX(120%)";

    }, 3000);

}

function addItem(item){

    let inventory = document.getElementById("inventoryList");

    // Remove placeholder when first real item is added
    if (inventory.children.length > 0) {

    let firstItem = inventory.children[0];

    if (firstItem.textContent.includes("Nothing Collected Yet")) {

        inventory.innerHTML = "";

    }

}

    // Prevent duplicate items
    let existingItems = inventory.querySelectorAll("li");

    for (let i = 0; i < existingItems.length; i++) {

        if (existingItems[i].textContent === "✨ " + item) {
            return;
        }

    }

    // Create new item
    let newItem = document.createElement("li");

    newItem.textContent = "✨ " + item;

    inventory.appendChild(newItem);

    // Show achievement popup
    showAchievement("First Discovery");

}
function showEnding(destiny){

    document.getElementById("gameScreen").style.display = "none";

    document.getElementById("endingScreen").style.display = "flex";

    document.getElementById("endingTitle").innerHTML =
    "PROJECT ELYSIUM<br><br>" +
    "Your Destiny: " + destiny +
    "<br><br>Every choice shapes your destiny.";

}